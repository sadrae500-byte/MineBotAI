package com.minebot.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.view.ViewGroup
import com.minebot.ai.capture.CaptureService

class MainActivity : Activity() {
    private val projectionRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        val title = TextView(this).apply {
            text = "MineBot AI"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "دستیار Minecraft Bedrock 1.21.51\n\nبرای شروع، مجوزهای لازم را فعال کن."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val overlay = makeButton("فعال‌سازی نمایش شناور") { requestOverlayPermission() }
        val accessibility = makeButton("فعال‌سازی سرویس کنترل لمسی") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val start = makeButton("اتصال تصویر بازی") { requestCapture() }
        val stop = makeButton("توقف MineBot AI") {
            stopService(Intent(this, CaptureService::class.java))
            status.text = "سرویس متوقف شد."
        }
        root.addView(title, matchWrap())
        root.addView(status, matchWrap())
        root.addView(overlay, matchWrap())
        root.addView(accessibility, matchWrap())
        root.addView(start, matchWrap())
        root.addView(stop, matchWrap())
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = 10
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else status.text = "مجوز نمایش شناور فعال است."
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "ابتدا مجوز نمایش شناور را فعال کن."
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Activity result API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "اتصال تصویر فعال شد. بازی را باز کن؛ کنترل خودکار به‌صورت پیش‌فرض خاموش است."
        } else status.text = "اجازه دریافت تصویر داده نشد."
    }
}
