package com.minebot.ai.vision

import android.graphics.Bitmap

/**
 * Lightweight frame diagnostics only. This deliberately does NOT claim to identify
 * Minecraft objects: reliable tree/ore/food recognition requires a trained model.
 */
data class FrameDiagnostics(
    val width: Int,
    val height: Int,
    val averageLuminance: Float,
    val greenPixelRatio: Float,
    val brownPixelRatio: Float,
    val bluePixelRatio: Float,
    val note: String
)

class VisionAnalyzer {
    fun analyze(bitmap: Bitmap): FrameDiagnostics {
        val w = bitmap.width
        val h = bitmap.height
        val stepX = (w / 100).coerceAtLeast(1)
        val stepY = (h / 100).coerceAtLeast(1)
        var count = 0
        var lum = 0.0
        var green = 0
        var brown = 0
        var blue = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                lum += 0.2126 * r + 0.7152 * g + 0.0722 * b
                if (g > r * 1.18 && g > b * 1.12) green++
                if (r > g * 1.18 && g > b * 1.08) brown++
                if (b > r * 1.15 && b > g * 1.05) blue++
                count++
                x += stepX
            }
            y += stepY
        }
        val denominator = count.coerceAtLeast(1).toFloat()
        return FrameDiagnostics(w, h, (lum / denominator / 255.0).toFloat(), green / denominator,
            brown / denominator, blue / denominator,
            "آمار رنگی تصویر؛ تشخیص قطعی بلوک یا موجودیت انجام نشده است.")
    }
}
