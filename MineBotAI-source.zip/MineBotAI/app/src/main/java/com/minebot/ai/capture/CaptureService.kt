package com.minebot.ai.capture

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import com.minebot.ai.control.MineBotAccessibilityService
import com.minebot.ai.vision.VisionAnalyzer

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "minebot_capture"
        private const val NOTIFICATION_ID = 51
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var toggleButton: Button? = null
    private var worker: Handler? = null
    private var workerThread: HandlerThread? = null
    private val analyzer = VisionAnalyzer()
    private var lastAnalysisAt = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        startWorker()
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP_MINEBOT") {
            MineBotAccessibilityService.instance?.stopAutomation()
            stopSelf()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                            else intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode == Activity.RESULT_OK && data != null && projection == null) beginCapture(resultCode, data)
        return START_NOT_STICKY
    }

    private fun beginCapture(resultCode: Int, data: Intent) {
        try {
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader?.setOnImageAvailableListener({ source -> analyzeLatest(source) }, worker)
            virtualDisplay = projection?.createVirtualDisplay(
                "MineBotScreen", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, worker
            )
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopCapture() }
            }, worker)
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در دریافت تصویر: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun analyzeLatest(source: ImageReader) {
        val image: Image = try { source.acquireLatestImage() ?: return } catch (_: Exception) { return }
        try {
            val now = System.currentTimeMillis()
            if (now - lastAnalysisAt < 1200) return
            lastAnalysisAt = now
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = android.graphics.Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, android.graphics.Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(buffer)
            val frame = android.graphics.Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            val diagnostics = analyzer.analyze(frame)
            frame.recycle()
            // Diagnostics are intentionally passive; no gameplay action is inferred from color ratios.
            toggleButton?.contentDescription = diagnostics.note
        } catch (_: Exception) {
            // A dropped frame is non-fatal; the next frame will be processed.
        } finally {
            image.close()
        }
    }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xDD17232D.toInt())
        }
        val toggle = Button(this).apply {
            text = "MineBot: خاموش"
            isAllCaps = false
            setOnClickListener {
                val service = MineBotAccessibilityService.instance
                val enable = !MineBotAccessibilityService.automationEnabled.get()
                if (enable && service == null) {
                    Toast.makeText(this@CaptureService, "ابتدا سرویس Accessibility را فعال کن.", Toast.LENGTH_SHORT).show()
                } else {
                    service?.setAutomation(enable)
                    text = if (enable) "MineBot: روشن" else "MineBot: خاموش"
                }
            }
        }
        val stop = Button(this).apply {
            text = "توقف فوری"
            isAllCaps = false
            setOnClickListener {
                MineBotAccessibilityService.instance?.stopAutomation()
                toggle.text = "MineBot: خاموش"
                Toast.makeText(this@CaptureService, "کنترل خودکار متوقف شد.", Toast.LENGTH_SHORT).show()
            }
        }
        panel.addView(toggle)
        panel.addView(stop)
        toggleButton = toggle
        overlay = panel
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 160 }
        try { windowManager?.addView(panel, params) } catch (_: Exception) { }
    }

    private fun startWorker() {
        workerThread = HandlerThread("MineBotFrameWorker").also { it.start() }
        worker = Handler(workerThread!!.looper)
    }

    private fun stopCapture() {
        virtualDisplay?.release(); virtualDisplay = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "MineBot AI screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, CaptureService::class.java).setAction("STOP_MINEBOT")
        val pending = PendingIntent.getService(this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("MineBot AI فعال است").setContentText("دریافت تصویر با اجازه کاربر")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause), "توقف", pending).build()).build()
        else Notification.Builder(this).setContentTitle("MineBot AI")
            .setContentText("دریافت تصویر فعال است").setSmallIcon(android.R.drawable.ic_media_play).build()
    }

    override fun onTaskRemoved(rootIntent: Intent?) { MineBotAccessibilityService.instance?.stopAutomation(); super.onTaskRemoved(rootIntent) }

    override fun onDestroy() {
        MineBotAccessibilityService.instance?.stopAutomation()
        stopCapture()
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        workerThread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

}
