package com.minebot.ai.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

/** Touch bridge. No gestures are issued unless the user explicitly enables automation. */
class MineBotAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: MineBotAccessibilityService? = null
            private set
        val automationEnabled = AtomicBoolean(false)
        val emergencyStop = AtomicBoolean(false)
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { stopAutomation() }
    override fun onDestroy() {
        stopAutomation()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun setAutomation(enabled: Boolean) {
        emergencyStop.set(!enabled)
        automationEnabled.set(enabled)
    }

    fun stopAutomation() {
        automationEnabled.set(false)
        emergencyStop.set(true)
    }

    fun tapNormalized(x: Float, y: Float): Boolean {
        if (!canAct()) return false
        val px = x.coerceIn(0f, 1f) * resources.displayMetrics.widthPixels
        val py = y.coerceIn(0f, 1f) * resources.displayMetrics.heightPixels
        val path = Path().apply { moveTo(px, py); lineTo(px + 1f, py + 1f) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 70)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun holdNormalized(x: Float, y: Float, durationMs: Long): Boolean {
        if (!canAct()) return false
        val px = x.coerceIn(0f, 1f) * resources.displayMetrics.widthPixels
        val py = y.coerceIn(0f, 1f) * resources.displayMetrics.heightPixels
        val path = Path().apply { moveTo(px, py) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceIn(100, 1500))
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun canAct() = Build.VERSION.SDK_INT >= 24 && automationEnabled.get() && !emergencyStop.get()
}
