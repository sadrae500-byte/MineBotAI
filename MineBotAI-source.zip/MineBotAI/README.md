# MineBot AI (Android)

Native Kotlin Android project targeting Android 10+ (minSdk 29), intended to accompany Minecraft Bedrock 1.21.51.

## Implemented in this source

- Persian launcher UI.
- User-approved MediaProjection screen capture in a foreground service.
- Floating overlay with explicit automation toggle and emergency stop.
- AccessibilityService gesture bridge with normalized screen coordinates and a hard enable/stop gate.
- Modular frame diagnostics that samples colors and luminance without claiming semantic Minecraft-object recognition.
- Capture and automation are stopped when the service is destroyed or the task is removed.

## Important capability boundary

This project is a native integration foundation, not yet a complete autonomous Minecraft-playing agent. Android's public Accessibility API can dispatch touch gestures, and MediaProjection can capture the screen after consent, but neither API exposes Minecraft's world state, inventory data, block IDs, or game-internal navigation. The included analyzer reports basic pixel statistics only. It does **not** reliably recognize trees, stone, food, enemies, hazards, or build structures. A production agent needs a trained on-device vision model (for example, a licensed TensorFlow Lite model trained on Minecraft Bedrock screenshots), a validated game-state/action model, and extensive device/game testing. No model weights are bundled and no autonomous action policy is enabled by default.

The game may change HUD/control layout with resolution, UI scale, split-screen, and user settings. Gesture coordinates currently use normalized full-screen coordinates; per-control calibration UI and safe gameplay policies remain future work.

## Setup on device

1. Install the APK after building.
2. Open MineBot AI and grant overlay permission.
3. Enable **MineBot AI** in Android Accessibility settings.
4. Tap **اتصال تصویر بازی** and approve Android's screen-capture prompt.
5. Open Minecraft. The floating panel appears. Automation is OFF by default; do not turn it on until a tested action policy and calibrated controls are available.
6. Use **توقف فوری** at any time.

## Build

Requires JDK 17, Android SDK Platform 35, Android Build Tools, and Gradle 8.9+ (Android Gradle Plugin 8.7.3). From this directory run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Testing status

This environment does not contain Gradle, Android SDK, ADB, or an Android emulator/device. Therefore the project could not be compiled, installed, or device-tested here. Do not treat the source as a verified release APK.
